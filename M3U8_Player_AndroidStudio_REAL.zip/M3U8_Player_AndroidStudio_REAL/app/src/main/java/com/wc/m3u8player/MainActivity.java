package com.wc.m3u8player;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;
    private EditText urlInput;
    private TextView statusText;
    private boolean fullscreen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerView = findViewById(R.id.playerView);
        urlInput = findViewById(R.id.urlInput);
        statusText = findViewById(R.id.statusText);
        Button playButton = findViewById(R.id.playButton);
        Button stopButton = findViewById(R.id.stopButton);
        Button fullscreenButton = findViewById(R.id.fullscreenButton);

        String savedUrl = getPreferences(MODE_PRIVATE).getString("last_url", "");
        urlInput.setText(savedUrl);

        initializePlayer();

        playButton.setOnClickListener(v -> playUrl());
        stopButton.setOnClickListener(v -> {
            if (player != null) {
                player.stop();
                statusText.setText("Parado");
            }
        });
        fullscreenButton.setOnClickListener(v -> toggleFullscreen());
    }

    private void initializePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_BUFFERING) statusText.setText("Carregando...");
                else if (playbackState == Player.STATE_READY) statusText.setText("Reproduzindo");
                else if (playbackState == Player.STATE_ENDED) statusText.setText("Finalizado");
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                statusText.setText("Erro: " + error.getErrorCodeName());
                Toast.makeText(MainActivity.this,
                        "Falha no stream: " + error.getErrorCodeName(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void playUrl() {
        String url = urlInput.getText().toString().trim();
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "Cole uma URL M3U8.", Toast.LENGTH_SHORT).show();
            return;
        }
        getPreferences(MODE_PRIVATE).edit().putString("last_url", url).apply();
        MediaItem item = MediaItem.fromUri(url);
        player.setMediaItem(item);
        player.prepare();
        player.play();
    }

    private void toggleFullscreen() {
        fullscreen = !fullscreen;
        View decorView = getWindow().getDecorView();
        if (fullscreen) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            WindowInsetsController controller = decorView.getWindowInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
            urlInput.setVisibility(View.GONE);
            statusText.setVisibility(View.GONE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            WindowInsetsController controller = decorView.getWindowInsetsController();
            if (controller != null) controller.show(WindowInsets.Type.systemBars());
            urlInput.setVisibility(View.VISIBLE);
            statusText.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
