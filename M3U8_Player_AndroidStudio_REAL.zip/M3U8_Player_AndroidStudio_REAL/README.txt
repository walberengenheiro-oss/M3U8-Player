M3U8 PLAYER - PROJETO ANDROID STUDIO REAL

Este projeto usa AndroidX Media3/ExoPlayer com suporte HLS.

Como gerar o APK no Android Studio:
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle Sync baixar as dependencias.
3. Menu Build > Build APK(s).
4. O APK debug sera criado em app/build/outputs/apk/debug/app-debug.apk.

Para um APK assinado:
Build > Generate Signed App Bundle or APK > APK.

Requisitos:
- Android Studio recente
- Android SDK 36
- JDK 17

Recursos:
- URL M3U8/HLS
- HTTP e HTTPS
- Play/Stop
- Controles Media3
- Tela cheia
- Ultima URL salva
- Mensagem de erro do ExoPlayer
