package com.wc.m3u8player;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_M3U_FILE = 1001;
    private static final Pattern ATTR_PATTERN = Pattern.compile("([A-Za-z0-9_-]+)=\\\"([^\\\"]*)\\\"");

    private ExoPlayer player;
    private PlayerView playerView;
    private EditText sourceInput;
    private EditText searchInput;
    private TextView statusText;
    private Spinner groupSpinner;
    private ListView channelList;
    private LinearLayout controlsPanel;
    private boolean fullscreen = false;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<PlaylistItem> allItems = new ArrayList<>();
    private final List<PlaylistItem> visibleItems = new ArrayList<>();
    private ArrayAdapter<String> channelAdapter;
    private ArrayAdapter<String> groupAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerView = findViewById(R.id.playerView);
        sourceInput = findViewById(R.id.sourceInput);
        searchInput = findViewById(R.id.searchInput);
        statusText = findViewById(R.id.statusText);
        groupSpinner = findViewById(R.id.groupSpinner);
        channelList = findViewById(R.id.channelList);
        controlsPanel = findViewById(R.id.controlsPanel);

        Button loadListButton = findViewById(R.id.loadListButton);
        Button openFileButton = findViewById(R.id.openFileButton);
        Button playDirectButton = findViewById(R.id.playDirectButton);
        Button fullscreenButton = findViewById(R.id.fullscreenButton);

        String savedSource = getPreferences(MODE_PRIVATE).getString("last_source", "");
        sourceInput.setText(savedSource);

        initializePlayer();
        setupListUi();

        loadListButton.setOnClickListener(v -> loadRemotePlaylist());
        openFileButton.setOnClickListener(v -> openPlaylistFile());
        playDirectButton.setOnClickListener(v -> playDirectUrl());
        fullscreenButton.setOnClickListener(v -> toggleFullscreen());
    }

    private void initializePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_BUFFERING) {
                    statusText.setText("Carregando mídia...");
                } else if (playbackState == Player.STATE_READY) {
                    if (TextUtils.isEmpty(statusText.getText())) statusText.setText("Reproduzindo");
                } else if (playbackState == Player.STATE_ENDED) {
                    statusText.setText("Finalizado");
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                statusText.setText("Erro de reprodução: " + error.getErrorCodeName());
                Toast.makeText(MainActivity.this,
                        "Falha ao reproduzir: " + error.getErrorCodeName(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setupListUi() {
        channelAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        channelList.setAdapter(channelAdapter);

        groupAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<>());
        groupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        groupSpinner.setAdapter(groupAdapter);

        channelList.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < visibleItems.size()) {
                playPlaylistItem(visibleItems.get(position));
            }
        });

        groupSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                applyFilters();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
                applyFilters();
            }
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applyFilters(); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void loadRemotePlaylist() {
        String url = sourceInput.getText().toString().trim();
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "Cole a URL de uma lista M3U.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            Toast.makeText(this, "Para lista online use uma URL http:// ou https://.", Toast.LENGTH_LONG).show();
            return;
        }

        saveLastSource(url);
        statusText.setText("Baixando lista M3U...");
        executor.execute(() -> {
            try {
                String content = downloadText(url);
                List<PlaylistItem> parsed = parseM3u(content, url);
                runOnUiThread(() -> showPlaylist(parsed, "Lista carregada"));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusText.setText("Erro ao carregar lista");
                    Toast.makeText(this, "Não foi possível abrir a lista: " + safeMessage(e), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void openPlaylistFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        String[] mimeTypes = {"audio/x-mpegurl", "application/x-mpegURL", "application/vnd.apple.mpegurl", "text/plain", "application/octet-stream"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        startActivityForResult(intent, PICK_M3U_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_M3U_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            statusText.setText("Lendo arquivo M3U...");
            executor.execute(() -> {
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new IOException("Arquivo não pôde ser aberto");
                    String content = readAll(input);
                    List<PlaylistItem> parsed = parseM3u(content, null);
                    runOnUiThread(() -> showPlaylist(parsed, "Arquivo carregado"));
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        statusText.setText("Erro ao ler arquivo");
                        Toast.makeText(this, "Falha no arquivo M3U: " + safeMessage(e), Toast.LENGTH_LONG).show();
                    });
                }
            });
        }
    }

    private void showPlaylist(List<PlaylistItem> parsed, String prefix) {
        allItems.clear();
        allItems.addAll(parsed);
        rebuildGroups();
        applyFilters();
        statusText.setText(prefix + ": " + allItems.size() + " itens");
        if (allItems.isEmpty()) {
            Toast.makeText(this, "A lista não contém canais/URLs reconhecidos.", Toast.LENGTH_LONG).show();
        }
    }

    private void rebuildGroups() {
        Set<String> groups = new LinkedHashSet<>();
        for (PlaylistItem item : allItems) {
            if (!TextUtils.isEmpty(item.group)) groups.add(item.group);
        }
        List<String> sorted = new ArrayList<>(groups);
        Collections.sort(sorted, String.CASE_INSENSITIVE_ORDER);

        groupAdapter.clear();
        groupAdapter.add("Todos os grupos");
        groupAdapter.addAll(sorted);
        groupAdapter.notifyDataSetChanged();
        groupSpinner.setSelection(0);
    }

    private void applyFilters() {
        if (channelAdapter == null) return;
        String query = searchInput == null ? "" : searchInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        String selectedGroup = "Todos os grupos";
        if (groupSpinner != null && groupSpinner.getSelectedItem() != null) {
            selectedGroup = groupSpinner.getSelectedItem().toString();
        }

        visibleItems.clear();
        channelAdapter.clear();
        for (PlaylistItem item : allItems) {
            boolean groupOk = "Todos os grupos".equals(selectedGroup) || selectedGroup.equals(item.group);
            String haystack = (item.name + " " + item.group).toLowerCase(Locale.ROOT);
            boolean searchOk = query.isEmpty() || haystack.contains(query);
            if (groupOk && searchOk) {
                visibleItems.add(item);
                channelAdapter.add(formatListItem(item));
            }
        }
        channelAdapter.notifyDataSetChanged();
    }

    private String formatListItem(PlaylistItem item) {
        if (TextUtils.isEmpty(item.group)) return item.name;
        return item.name + "\n" + item.group;
    }

    private void playDirectUrl() {
        String url = sourceInput.getText().toString().trim();
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "Cole a URL de uma mídia/stream.", Toast.LENGTH_SHORT).show();
            return;
        }
        saveLastSource(url);
        playMedia(url, "URL direta");
    }

    private void playPlaylistItem(PlaylistItem item) {
        playMedia(item.url, item.name);
    }

    private void playMedia(String url, String title) {
        try {
            MediaItem.Builder builder = new MediaItem.Builder().setUri(url);
            String clean = url.toLowerCase(Locale.ROOT);
            if (clean.contains(".m3u8")) builder.setMimeType(MimeTypes.APPLICATION_M3U8);
            MediaItem item = builder.build();
            player.setMediaItem(item);
            player.prepare();
            player.play();
            statusText.setText("Reproduzindo: " + title);
        } catch (Exception e) {
            statusText.setText("Erro ao abrir mídia");
            Toast.makeText(this, "URL inválida: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private String downloadText(String sourceUrl) throws IOException {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(sourceUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(25000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "M3U-Player-Android/2.0");
            connection.setRequestProperty("Accept", "*/*");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
            try (InputStream input = connection.getInputStream()) {
                return readAll(input);
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readAll(InputStream input) throws IOException {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line).append('\n');
            }
        }
        if (out.length() > 0 && out.charAt(0) == '\uFEFF') out.deleteCharAt(0);
        return out.toString();
    }

    private List<PlaylistItem> parseM3u(String content, @Nullable String baseUrl) {
        List<PlaylistItem> result = new ArrayList<>();
        String[] lines = content.replace("\r", "").split("\n");

        String pendingName = null;
        String pendingGroup = "";
        String currentExtGroup = "";
        int unnamed = 1;

        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("#EXTGRP:")) {
                currentExtGroup = line.substring(8).trim();
                continue;
            }

            if (line.startsWith("#EXTINF:")) {
                String metadata = line;
                String displayName = "";
                int comma = line.indexOf(',');
                if (comma >= 0 && comma + 1 < line.length()) displayName = line.substring(comma + 1).trim();

                String tvgName = extractAttribute(metadata, "tvg-name");
                String group = extractAttribute(metadata, "group-title");
                if (TextUtils.isEmpty(displayName)) displayName = tvgName;
                if (TextUtils.isEmpty(displayName)) displayName = "Canal " + unnamed++;
                if (TextUtils.isEmpty(group)) group = currentExtGroup;

                pendingName = displayName;
                pendingGroup = group == null ? "" : group;
                continue;
            }

            if (line.startsWith("#")) continue;

            String resolved = resolveUrl(baseUrl, line);
            if (resolved == null || resolved.isEmpty()) continue;
            String name = pendingName;
            if (TextUtils.isEmpty(name)) name = guessNameFromUrl(resolved, unnamed++);
            result.add(new PlaylistItem(name, pendingGroup, resolved));
            pendingName = null;
            pendingGroup = "";
        }
        return result;
    }

    private String extractAttribute(String line, String key) {
        Matcher matcher = ATTR_PATTERN.matcher(line);
        while (matcher.find()) {
            if (key.equalsIgnoreCase(matcher.group(1))) return matcher.group(2).trim();
        }
        return "";
    }

    private String resolveUrl(@Nullable String baseUrl, String value) {
        try {
            if (baseUrl == null || value.contains("://")) return value;
            return URI.create(baseUrl).resolve(value).toString();
        } catch (Exception e) {
            return value;
        }
    }

    private String guessNameFromUrl(String url, int index) {
        try {
            Uri uri = Uri.parse(url);
            String segment = uri.getLastPathSegment();
            if (!TextUtils.isEmpty(segment)) return segment;
        } catch (Exception ignored) { }
        return "Item " + index;
    }

    private void saveLastSource(String source) {
        getPreferences(MODE_PRIVATE).edit().putString("last_source", source).apply();
    }

    private void toggleFullscreen() {
        fullscreen = !fullscreen;
        View decorView = getWindow().getDecorView();
        WindowInsetsController controller = decorView.getWindowInsetsController();
        if (fullscreen) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
            controlsPanel.setVisibility(View.GONE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            if (controller != null) controller.show(WindowInsets.Type.systemBars());
            controlsPanel.setVisibility(View.VISIBLE);
        }
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return TextUtils.isEmpty(message) ? e.getClass().getSimpleName() : message;
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }

    private static class PlaylistItem {
        final String name;
        final String group;
        final String url;

        PlaylistItem(String name, String group, String url) {
            this.name = name;
            this.group = group == null ? "" : group;
            this.url = url;
        }
    }
}
