M3U PLAYER - LISTA IPTV - ANDROID STUDIO

Versao 2.0: agora o app e um reprodutor de LISTA M3U, e nao apenas um campo para M3U8.

Recursos:
- Carrega lista M3U por URL HTTP/HTTPS
- Abre arquivo M3U local pelo seletor do Android
- Le #EXTM3U, #EXTINF, tvg-name e group-title
- Lista canais/itens e permite tocar para reproduzir
- Filtro por grupo/categoria
- Pesquisa de canais
- Continua aceitando URL M3U8 direta
- Reproduz streams suportados pelo Media3/ExoPlayer (HLS, MP4, MPEG-TS e outros formatos compativeis)
- HTTP e HTTPS
- Player Media3 com controles
- Tela cheia
- Ultima fonte salva

Compilacao: Android SDK 36, JDK 17, Android Gradle Plugin 9.4.0.
